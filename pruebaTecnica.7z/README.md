## Development server
Run NPM I to install all dependencies and then Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

At the first, you need to register new account into register zone, and then log with the username/password.

Search for any movie, add to favorites with + symbol or just go to details to see more information about the movie.

You can see your favorite movies into the Favorites zone. 


Angular version 8.3.23.



