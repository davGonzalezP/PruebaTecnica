import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  logged: boolean;

  constructor() { }
  /**
   * get the user if exist
   */
  getUser() {
    if (sessionStorage['User']) {
      return JSON.parse(sessionStorage.getItem('User'));
    }
  }
  /**
   * Create a new user and return observable with the user created
   * @param userName 
   * @param password 
   */
  setNewUser(userName, password): Observable<any> {
    const user = {
      'userName': userName,
      'password': password
    }
    sessionStorage.setItem('User', JSON.stringify(user));

    if (sessionStorage['User']) {
      return of(sessionStorage['User']);
    }
  }
  /**
   * Set the login state
   * @param param 
   */
  loginState(param: boolean) {
    this.logged = param;
  }
  /**
   * Check if the user is logged
   */
  isLogged() {
    return this.logged;
  }

}
