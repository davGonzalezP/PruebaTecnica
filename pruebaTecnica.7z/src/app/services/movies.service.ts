import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { movie } from '../models/interface';
@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  url = 'http://www.omdbapi.com/?apikey=f12ba140&';
  lastSearch: string;
  all: Array<any> = [];
  details: Array<any> = [];
  constructor(private http: HttpClient) {
  }
  /**
   * Get the movies from api
   * @param title 
   * @param type 
   */
  getMovies(title, type) {
    const body = {
      s: title,
      type: type
    }
    return this.http.get(this.url, { params: body });
  }
  /**
   * Set the last movie searched
   * @param param 
   */
  setLastMovieSearch(param) {
    this.lastSearch = param;
  }
  /**
   * Get the last movie searched
   */
  getLastMovieSearch() {
    return this.lastSearch;
  }
  /**
   * Change param to t , to get full info, to show on details-component
   * @param title 
   * @param type 
   */
  getMoviesFullInfo(title, type) {
    const body = {
      t: title,
      type: type
    }
    return this.http.get(this.url, { params: body });
  }
  /**
   * Save favorites into array 'all'
   * @param item 
   */

  saveFavorites(item) {
    const found = this.all.find(element => element['Title'] === item['Title']) ? true : false;
    if (!found) {
      this.all.push(item);
    }
  }
  /**
   * Get the 'all' array
   */

  getFavorites() {
    return this.all;
  }
  /**
   * Delete favorites from all array
   * @param item 
   */
  deleteFavorites(item) {
    this.all.forEach(function (itemToCheck, index, object) {
      if (itemToCheck['Title'] == item) {
        object.splice(index, 1);
      }
    });
  }

  /**
   * Save the favorites when recharge the app and click new favorites
   * //TODO: rfactor
   */
  getOldfFav() {
    if (localStorage.getItem("favorites") != null) {
      const locaStorage = JSON.parse(localStorage.getItem('favorites'));
      locaStorage.forEach(element => {
        this.all.push(element);
      });
    }
  }
  /**
   * Set details
   * @param detail 
   */
  
  setDetails(detail) {
    this.details = [];
    this.details = detail;
/**
   * get Details
   * 
   */
  }
  getDetails() {
    return this.details;

  }
  /**
   * Get all localStorage
   * TODO: // Refactoring to this, to delete the current dev
   */
  allStorage() {

    var values = [],
      keys = Object.keys(localStorage),
      i = keys.length;

    while (i--) {
      values.push(localStorage.getItem(keys[i]));
    }

    return values;
  }
}
