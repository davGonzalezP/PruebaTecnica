import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './guards/auth.guard'
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: '', loadChildren: () => import('./components/movies/movies.module').then(m => m.MoviesModule), canActivate: [AuthGuard] },
  { path: 'movies', loadChildren: () => import('./components/movies/movies.module').then(m => m.MoviesModule), canActivate: [AuthGuard] },
  { path: 'movies-detail/:id', loadChildren: () => import('./components/movies-detail/movies-detail.module').then(m => m.MoviesDetailModule), canActivate: [AuthGuard] },
  { path: 'register', loadChildren: () => import('./components/register/register.module').then(m => m.RegisterModule) },
  { path: 'favorites', loadChildren: () => import('./components/favorites/favorites.module').then(m => m.FavoritesModule), canActivate: [AuthGuard] },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
