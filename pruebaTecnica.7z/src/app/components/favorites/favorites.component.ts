import { Component, OnInit } from '@angular/core';
import { MoviesComponent } from '../movies/movies.component';

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.css']
})
export class FavoritesComponent extends MoviesComponent implements OnInit {
  favorites: Array<any> = [];
  super() { }

  ngOnInit() {
    this.getFavorites();
  }
  /**
   * get Favorites
   */
  getFavorites() {
    // TODO: Pdte refactorizar como set y get el tema del localStorage 
    //console.log(this.movies.allStorage());
    
    this.favorites = this.movies.getFavorites(); 
  }
}
