import { Component, OnInit } from '@angular/core';
import { LoginComponent } from '../login/login.component';
import { constants } from 'src/app/constants/constants';
import { login } from 'src/app/models/interface';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent extends LoginComponent implements OnInit {
  myConstant: any = constants;
  missingFields: boolean = false;
  super() { }

  ngOnInit() {

  }
  /**
   * Create register form from father
   */
  registerForm = this.loginForm;
  /**
   * When submit the form, set new user into the service.
   */
  onSubmit() {
    const userName = this.registerForm.get('userName').value;
    const pwd = this.registerForm.get('password').value;

    if (userName && pwd) {

      this.loginService.setNewUser(userName, pwd).subscribe((data: login) => {
        this.router.navigateByUrl('/login');
        this.missingFields = false;
      });
    } else{
      this.missingFields = true;
    }
  }

}
