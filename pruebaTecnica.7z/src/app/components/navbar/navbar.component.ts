import { Component, OnInit } from '@angular/core';
import { constants } from '../../constants/constants'
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  myConstant: any = constants;
  constructor() { }

  ngOnInit() {

  }

}
