import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { login } from '../../models/interface'
import { Router } from '@angular/router';
import { constants } from '../../constants/constants'
import { MoviesService } from 'src/app/services/movies.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  notLogged: boolean = false;
  checkLogin: login;
  myConstant: any = constants;
  constructor(
    public loginService: LoginService,
    public router: Router,
    private movies: MoviesService
  ) {
   }

  ngOnInit() {
    this.movies.getOldfFav();
  }
  /**
   * Form build
   */
  loginForm = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  })

  /**
   * execute when send the form
   */

  onSubmit() {
    const userName = this.loginForm.get('userName').value;
    const pwd = this.loginForm.get('password').value;

    this.checkLogin = this.loginService.getUser();
    
    this.checkUser(this.checkLogin, userName, pwd);
  }
  /**
   * Function to create a new user 
   * @param userName 
   * @param pwd 
   */
  createUser(userName, pwd) {
    this.loginService.setNewUser(userName, pwd);
  }

  /**
   * get the users from session storage, user and password to check what to do
   * @param checkLogin 
   * @param userName 
   * @param pwd 
   */

  checkUser(checkLogin, userName, pwd) {
    if (checkLogin && checkLogin.userName === userName && checkLogin.password === pwd) {
      this.loginService.loginState(true);
      this.router.navigateByUrl("/movies");
      this.notLogged = false;
    } else {
      this.notLogged = true;
    }
  }

}
