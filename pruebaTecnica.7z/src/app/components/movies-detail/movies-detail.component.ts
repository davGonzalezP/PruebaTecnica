import { Component, OnInit } from '@angular/core';
import { MoviesComponent } from '../movies/movies.component';
import {movie, infoMovie} from '../../models/interface'

@Component({
  selector: 'app-movies-detail',
  templateUrl: './movies-detail.component.html',
  styleUrls: ['./movies-detail.component.css']
})
export class MoviesDetailComponent extends MoviesComponent implements OnInit {
  movieToShow: any;
  infoToShow:infoMovie;
  super() { }

  ngOnInit() {

    // this.movieToShow = JSON.parse(localStorage.getItem('details'));
    this.movieToShow = this.movies.getDetails();
    this.getInfo();
  }

goBack(){
  this.location.back();
}
getInfo(){
  this.movies.getMoviesFullInfo(this.movieToShow.Title, 'movie').subscribe((data:infoMovie) =>{
    this.infoToShow= data; 
  })
}

}
