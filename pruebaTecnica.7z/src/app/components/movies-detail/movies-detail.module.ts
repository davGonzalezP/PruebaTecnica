import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MoviesDetailRoutingModule } from './movies-detail-routing.module';
import { MoviesDetailComponent } from './movies-detail.component';


@NgModule({
  declarations: [MoviesDetailComponent],
  imports: [
    CommonModule,
    MoviesDetailRoutingModule
  ]
})
export class MoviesDetailModule { }
