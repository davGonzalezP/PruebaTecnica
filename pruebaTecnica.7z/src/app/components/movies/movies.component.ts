import { Component, OnInit } from '@angular/core';
import { MoviesService } from 'src/app/services/movies.service';
import { movie } from 'src/app/models/interface';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { constants } from 'src/app/constants/constants';
@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  theMovies;
  failed: boolean;
  error: any;
  movieName: string;
  myConstants = constants;
  constructor(
    public movies: MoviesService,
    public router: Router,
    public route: ActivatedRoute,
    public location: Location,
  ) { }

  ngOnInit() {
    this.keepTheMovie();
  }
  /**
  * Form build
  */
  searchForm = new FormGroup({
    movie: new FormControl('', Validators.required),
  })
  /**
   * add the movie to details locastorage and navigate to 
   * @param movie 
   * @param index 
   */
  navigate(movie, index) {
    this.movies.setDetails(movie);
    this.router.navigate(['/movies-detail/', index])
  }
  /**
   * Add localstorage item, if type is true, save into favorites, else details
   * @param movie 
   * @param type 
   */
  addToLocalStorage(movie: any, type: boolean) {
    this.movies.saveFavorites(movie);
    localStorage.setItem('favorites', JSON.stringify(this.movies.getFavorites()))
  }
  /**
   * Remove favorites from favorites localStorage Item
   * @param name 
   */
  removeToLocalStorage(name: string) {
    this.movies.deleteFavorites(name);
    localStorage.removeItem('favorites');
    localStorage.setItem('favorites', JSON.stringify(this.movies.getFavorites()))
  }

  /**
   * Search movies if fails or doesnt found, failed true and get the error 
   */

  searchMovie() {
    this.movieName = this.searchForm.get('movie').value;
    this.movies.getMovies(this.movieName, 'movie').subscribe(data => {
      this.failed = false;
      this.theMovies = data;
      this.lastSearched(this.movieName);
      if (data['Response']) {
        this.failed = true
        this.error = data['Error']
      }
    })
  }
  /**
   * Save the last movie 
   * @param movieName 
   */
  lastSearched(movieName) {
    this.movies.setLastMovieSearch(movieName);
  }
  /**
   * Set the last movie into input and search it again
   */
  keepTheMovie() {
    if (this.movies.getLastMovieSearch()) {
      this.searchForm.get('movie').setValue(this.movies.getLastMovieSearch());
      this.searchMovie();
    }
  }
}
