export const constants = {
    loginComponent: {
        username: 'User Name',
        password: 'Password',
        sign: 'Sign-in',
        error:'User/Password not correct or you didnt register yet',
        register:'Register your account'
    },
    registerComponent: {
        username: 'User Name',
        password: 'Password',
        register: 'Register',
        missingFields: 'Fields cant be empty',
    },
    navBarComponent:{

        Movies: 'Movies',
        Favorites: 'Favorites',
    },
    favoritesComponent:{
        Favorites: 'Favorite Movies',
        Delete: 'Delete',
    },
    moviesComponent:{
        Details:'Go to details',
    },
    moviesDetail:{
        Description:'Movie Description',
        Details:'Movie Details',

    },
    notFoundComponent:{
        Code: '404',
        Text:'The page you requested was not found.'
    }

}